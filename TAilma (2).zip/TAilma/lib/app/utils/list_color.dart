class ListColor {
  static final colorBackground = 0xFFF5F5F5;
  static final colorButtonGreen = 0xFF569F00;
  static const colorTextGray = 0xFF8391A1;
  static const colorButtonGray = 0xFFEAEAEA;
  static const colorBackgroundGray = 0xFFF5F5F5;
}
